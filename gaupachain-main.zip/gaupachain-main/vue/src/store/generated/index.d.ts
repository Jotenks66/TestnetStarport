declare const _default: {
    GaupaLabsGaupachainGaupaLabsGaupachainGaupachain: (store: any) => void;
};
export default _default;
