import { Post } from "./module/types/gaupachain/post";
export { Post };
declare const _default;
export default _default;
