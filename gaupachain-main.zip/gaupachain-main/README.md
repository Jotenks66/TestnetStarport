# gaupachain
A Terndermint based Blockchain created using the Cosmos SDK
